from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .forms import FarmerRegistrationForm 
from .models import Fusers  
from .models import Soil 
from .forms import SoilForm
from .models import Fertilizer
from .forms import FertilizerForm
from .models import View_Soil_Info
from .models import Product, Order
from .forms import ProductForm
from .models import Feedback
from .forms import FeedbackForm, ResponseForm
from .models import Response


from .ml.predict_fertilizer import recommend_fertilizer

def index(request):
    all_farmers = Fusers.objects.all()
    return render(request, 'index.html', {'farmers': all_farmers})

def register(request):
    if request.method == 'POST':
        form = FarmerRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()  # Creates the new user
            messages.success(request, 'Registration successful! You can now log in.')
            return redirect('farmer_login')  # Go to the farmer login page
    else:
        form = FarmerRegistrationForm()
    return render(request, 'register.html', {'form': form})


def admin_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Hard-coded credentials
        valid_username = "Admin"
        valid_password = "Oneword123"

        if username == valid_username and password == valid_password:
            # Try to get the user; if not found, create one
            try:
                user = User.objects.get(username=valid_username)
            except User.DoesNotExist:
                user = User.objects.create_user(username=valid_username, password=valid_password)
                user.is_staff = True
                user.is_superuser = True
                user.save()
            login(request, user)
            return redirect('admin_dashboard')
        else:
            messages.error(request, 'Invalid credentials or not an admin user.')

    return render(request, 'admin_login.html')




@login_required
def admin_dashboard(request):
    # Only allow staff or superuser to see the dashboard
    if not request.user.is_staff:
        messages.error(request, 'You are not authorized to view the admin dashboard.')
        return redirect('admin_login')
    
    return render(request, 'admin_dashboard.html')

def admin_logout(request):
    logout(request)
    return redirect('admin_login')

def farmer_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Hard-coded credentials
        valid_username = "Jnana"
        valid_password = "Jnana@15"

        if username == valid_username and password == valid_password:
            # Try to get the user; if not found, create one
            try:
                user = User.objects.get(username=valid_username)
            except User.DoesNotExist:
                user = User.objects.create_user(username=valid_username, password=valid_password)
                user.is_staff = True
                user.is_superuser = True
                user.save()
            login(request, user)
            return redirect('farmer_dashboard')
        else:
            messages.error(request, 'Invalid credentials or not an farmer user.')

    return render(request, 'farmer_login.html')




@login_required
def farmer_dashboard(request):
    if not request.user.is_authenticated:
        return redirect('farmer_login')
    # Only logged-in users can see this page
    return render(request, 'farmer_dashboard.html')

def farmer_logout(request):
    logout(request)
    return redirect('farmer_login')

def update_password(request):
    # For now, just render the template with the update password form.
    return render(request, 'update_password.html')

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Hard-coded credentials
        valid_username = "Anand"
        valid_password = "Anand@15"

        if username == valid_username and password == valid_password:
            # Try to get the user; if not found, create one
            try:
                user = User.objects.get(username=valid_username)
            except User.DoesNotExist:
                user = User.objects.create_user(username=valid_username, password=valid_password)
                user.is_staff = True
                user.is_superuser = True
                user.save()
            login(request, user)
            return redirect('user_dashboard')
        else:
            messages.error(request, 'Invalid credentials or not an user.')

    return render(request, 'user_login.html')

@login_required
def user_dashboard(request):
    products = Product.objects.all()
    if not request.user.is_authenticated:
        return redirect('user_login')
    return render(request, 'user_dashboard.html', {'products': products})

def user_logout(request):
    logout(request)
    return redirect('user_login')

def view_farmers(request):
    farmers = Fusers.objects.all()  # Fetch all farmers from the DB
    context = {
        'farmers': farmers
    }
    return render(request, 'farmerdetails.html', context)

def delete_farmer(request, id):
    if request.method == 'POST':
        # Example: fetch the farmer by ID and delete
        farmer = Fusers.objects.get(pk=id)
        farmer.delete()
    return redirect('view_farmers')

def add_soil_details(request):
    """
    Renders a form to add soil details. On POST, validates and saves the data.
    """
    if request.method == 'POST':
        form = SoilForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Soil details added successfully!')
            return redirect('manage_soil_details')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = SoilForm()
    return render(request, 'soildetails.html', {'form': form})

def manage_soil_details(request):
    """
    Retrieves all soil records from the database and displays them in a table.
    """
    soils = Soil.objects.all()
    return render(request, 'managesoildetails.html', {'soils': soils})


def update_soil(request, soil_id):
    soil = get_object_or_404(Soil, pk=soil_id)
    if request.method == 'POST':
        form = SoilForm(request.POST, instance=soil)
        if form.is_valid():
            form.save()
            return redirect('manage_soil_details')
    else:
        # Pre-fill the form with the existing Soil object
        form = SoilForm(instance=soil)

    return render(request, 'update_soil.html', {'form': form, 'soil': soil})


def delete_soil(request, soil_id):
    if request.method == 'POST':
        # fetch soil by ID and delete
        Soil.objects.filter(id=soil_id).delete()
    return redirect('manage_soil_details')

def add_fertilizer(request):
    if request.method == "POST":
        form = FertilizerForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('manage_fertilizer')  # Redirect to manage fertilizers page
    else:
        form = FertilizerForm()
    return render(request, 'add_fertilizer.html', {'form': form})

def manage_fertilizer(request):
    fertilizers = Fertilizer.objects.all()
    return render(request, 'manage_fertilizer.html', {'fertilizers': fertilizers})


def update_fertilizer(request, id):
    fertilizer = get_object_or_404(Fertilizer, id=id)
    if request.method == "POST":
        form = FertilizerForm(request.POST, request.FILES, instance=fertilizer)
        if form.is_valid():
            form.save()
            return redirect('manage_fertilizer')
    else:
        form = FertilizerForm(instance=fertilizer)
    return render(request, 'update_fertilizer.html', {'form': form})

# Delete Fertilizer
def delete_fertilizer(request, id):
    fertilizer = get_object_or_404(Fertilizer, id=id)
    if request.method == "POST":
        fertilizer.delete()
        return redirect('manage_fertilizer')
    return render(request, 'delete_fertilizer.html', {'fertilizer': fertilizer})

def view_soil_info(request):
    soils = Soil.objects.all()
    return render(request, 'view_soil_info.html', {'soils': soils})

def view_fertilizer_info(request):
    fertilizers = Fertilizer.objects.all()
    return render(request, 'view_fertilizer_info.html', {'fertilizers': fertilizers})

def add_product(request):
    form = ProductForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        product = form.save(commit=False)
        product.farmer = request.user
        product.save()
        return redirect('manage_product')
    return render(request, 'add_product.html', {'form': form})

def manage_product(request):
    products = Product.objects.filter(farmer=request.user)
    return render(request, 'manage_product.html', {'products': products})





@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    product.delete()
    return redirect('manage_product')

@login_required
def update_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    form = ProductForm(request.POST or None, request.FILES or None, instance=product)
    if form.is_valid():
        form.save()
        return redirect('manage_product')
    return render(request, 'add_product.html', {'form': form})

def send_feedback(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_response')
    else:
        form = FeedbackForm(initial={'user_name': request.user.username})
    return render(request, 'send_feedback.html', {'form': form})

def view_response(request):
    responses = Feedback.objects.filter(user_name=request.user.username)
    return render(request, 'view_response.html', {'responses': responses})

def send_response(request):
    feedbacks = Feedback.objects.all()
    if request.method == 'POST':
        fid = request.POST.get('fid')
        feedback = get_object_or_404(Feedback, id=fid)
        feedback.response = request.POST.get('response')
        feedback.save()
        return redirect('send_response')
    return render(request, 'send_response.html', {'feedbacks': feedbacks})

def buy_product_page(request):
    products = Product.objects.all()
    return render(request, 'buy_product.html', {'products': products})
    product = get_object_or_404(Product, id=product_id)
    Order.objects.create(user=request.user, product=product)
    return redirect('order_status')


@login_required
def buy_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    # Prevent duplicate orders (optional)
    existing = Order.objects.filter(user=request.user, product=product, status='pending').first()
    if not existing:
        Order.objects.create(user=request.user, product=product)
    return redirect('order_status')

@login_required
def cancel_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    if order.status == 'pending':
        order.status = 'cancelled'  # Or delete: order.delete()
        order.save()
    return redirect('order_status')

@login_required
def order_status(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'order_status.html', {'orders': orders})

@login_required
def cancel_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    if order.status == 'pending':
        order.status = 'cancelled'
        order.save()
    return redirect('order_status')

@login_required
def view_order(request):
    orders = Order.objects.filter(product__farmer=request.user)
    return render(request, 'view_order.html', {'orders': orders})

@login_required
def respond_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, product__farmer=request.user)
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'accept':
            order.status = 'accepted'
        elif action == 'reject':
            order.status = 'rejected'
        order.save()
    return redirect('view_order')

@login_required
def view_orders(request):
    orders = Order.objects.filter(product__farmer=request.user)
    return render(request, 'view_order.html', {'orders': orders})
 

@login_required
def payment_page(request):
    orders = Order.objects.filter(user=request.user, status='accepted', paid=False)
    return render(request, 'payment.html', {'orders': orders})

@login_required
def make_payment(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    if request.method == 'POST' and order.status == 'accepted' :
        order.paid = True
        order.save()
    return redirect('order_status')

@login_required
def payment_single(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user, status='accepted', paid=False)
    return render(request, 'payment_single.html', {'order': order})

@login_required
def view_payment_info(request):
    orders = Order.objects.filter(product__farmer=request.user, paid=True)
    return render(request, 'view_payment.html', {'orders': orders})

@login_required
def update_delivery_status(request, order_id):
    order = get_object_or_404(Order, id=order_id, product__farmer=request.user)
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'done':
            order.delivery_status = 'done'
        elif action == 'not done':
            order.delivery_status = 'not done'
        order.save()
    return redirect('view_payment')

@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user, paid=True)
    return render(request, 'order_history.html', {'orders': orders})





def fertilizer_recommend_view(request):
    if request.method == "POST":
        soil = request.POST.get("soil")
        region = request.POST.get("region")
        recommendation = recommend_fertilizer(soil, region)
        return render(request, "recommend_result.html", {"fertilizer": recommendation})
    return render(request, "recommend_form.html")
