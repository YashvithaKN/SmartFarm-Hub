
from django.db import models
from django.contrib.auth.models import User


class Fusers(models.Model):
    fullname = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    username = models.CharField(max_length=150, unique=True)
    phone = models.CharField(max_length=20)
    address = models.TextField()
    role = models.CharField(max_length=50, default='user')  # Ensure this exists
    
    def __str__(self):
        return self.username

class Soil(models.Model):
    SOIL_TYPES = [
        ('Red', 'Red Soil'),
        ('Black', 'Black Soil'),
        ('Alluvial', 'Alluvial Soil'),
        ('Laterite', 'Laterite Soil'),
        ('Peaty', 'Peaty Soil'),
        ('Saline', 'Saline Soil'),
        ('Desert', 'Desert Soil'),
    ]
    soil_type = models.CharField(max_length=50, choices=SOIL_TYPES) 
    REGION = [
        ("Chikkamagaluru", "Chikkamagaluru"),
        ("Bengaluru", "Bengaluru"),
        ("Mysuru", "Mysuru"),
        ("Mangaluru", "Mangaluru"),
        ("Hubballi", "Hubballi"),
        ("Dharwad", "Dharwad"),
   	("Belagavi", "Belagavi"),
    	("Ballari", "Ballari"),
    	("Kalaburagi", "Kalaburagi"),
    	("Bidar", "Bidar"),
    	("Raichur", "Raichur"),
    	("Shivamogga", "Shivamogga"),
    	("Tumakuru", "Tumakuru"),
    	("Vijayapura", "Vijayapura"),
        ("Hassan", "Hassan"),
    	("Mandya", "Mandya"),
    	("Bagalkot", "Bagalkot"),
    	("Chitradurga", "Chitradurga"),
    	("Davangere", "Davangere"),
    	("Kolar", "Kolar"),
    	("Chikkaballapur", "Chikkaballapur"),
    	("Yadgir", "Yadgir"),
    	("Ramanagara", "Ramanagara"),
    	("Udupi", "Udupi"),
    	("Karwar", "Karwar"),
    	("Sirsi", "Sirsi"),
    	("Gangavati", "Gangavati"),
	("Hospet", "Hospet"),
    	("Madikeri", "Madikeri"),
    	("Haveri", "Haveri"),
    	("Gadag", "Gadag"),
    	("Tiptur", "Tiptur"),
    	("Ranebennur", "Ranebennur"),
    	("Bhadravati", "Bhadravati"),
    	("Sagar", "Sagar"),
    	("Dandeli", "Dandeli"),
    	("Bhatkal", "Bhatkal"),
    	("Kundapura", "Kundapura"),
    	("Sindhanur", "Sindhanur"),
    	("Puttur", "Puttur"),
    	("Sira", "Sira"),
    	("Nanjangud", "Nanjangud"),
    	("Basavakalyan", "Basavakalyan"),
    	("Channapatna", "Channapatna"),
    	("Talikoti", "Talikoti"),
    	("Yelahanka", "Yelahanka"),
    	("Koppal", "Koppal"),
    	("Holalkere", "Holalkere"),
    	("Kudligi", "Kudligi"),

    ]
    region = models.CharField(max_length=100, choices=REGION)

    def __str__(self):
        return f"{self.soil_type} - {self.region}"

class Fertilizer(models.Model):
    FERTILIZER_TYPES = [
        ('Organic', 'Organic'),
        ('Chemical', 'Chemical'),
    ]
    
    name = models.CharField(max_length=255)
    type = models.CharField(max_length=50, choices=FERTILIZER_TYPES)
    image = models.ImageField(upload_to='fertilizers/')
    description = models.TextField()

    def __str__(self):
        return self.name

class View_Soil_Info(models.Model):
    sid = models.AutoField(primary_key=True)
    soil_name = models.CharField(max_length=100)
    region = models.CharField(max_length=200)

    def __str__(self):
        return self.soil_name

class Region(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class View_Fertilizer_Info(models.Model):
    name = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    image = models.ImageField(upload_to='fertilizers/')
    description = models.TextField()

    def __str__(self):
        return self.fertilizer_name

class Product(models.Model):
    farmer = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='product_image/')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    about = models.TextField()

    def __str__(self):
        return self.name


class Feedback(models.Model):
    user_name = models.CharField(max_length=100)
    farmer_name = models.CharField(max_length=100)
    rating = models.IntegerField()
    message = models.TextField()
    response = models.TextField(blank=True)

    def __str__(self):
        return f"Feedback from {self.user_name} to {self.farmer_name}"

class Response(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    feedback = models.TextField()
    reply = models.TextField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Response from {self.user.username}"

class Order(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('cancelled', 'Cancelled'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    paid = models.BooleanField(default=False)
    delivery_status = models.CharField(max_length=20, default='pending')
    choices=[
        ('not done', 'Not Done'),
        ('done', 'Done')
    ]
     