import joblib
import pandas as pd
import os

model_path = os.path.join(os.path.dirname(__file__), "fertilizer_model.pkl")
model = joblib.load(model_path)

def recommend_fertilizer(soil, region):
    input_df = pd.DataFrame([{
        f"Soil_Type_{soil}": 1,
        f"Region_{region}": 1
    }])

    # Ensure all training columns exist in input
    for col in model.feature_names_in_:
        if col not in input_df.columns:
            input_df[col] = 0

    input_df = input_df[model.feature_names_in_]
    return model.predict(input_df)[0]
