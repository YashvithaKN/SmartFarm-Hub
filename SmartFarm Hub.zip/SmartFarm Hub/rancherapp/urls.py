"""
URL configuration for ranchersmate project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path, include
from . import views  
from django.contrib.auth import views as auth_views
from .views import index
from .views import register
from .views import admin_login
from .views import admin_dashboard
from .views import admin_logout 
from .views import farmer_login
from .views import farmer_dashboard
from .views import farmer_logout
from .views import update_password
from .views import user_login 
from .views import user_dashboard
from .views import user_logout
from .views import user_dashboard
from .views import add_fertilizer, manage_fertilizer, update_fertilizer, delete_fertilizer
from .views import add_product, manage_product, delete_product
from .views import send_response, send_feedback, view_response

urlpatterns = [
    path('', index, name='index'),
    path('register/', register, name='register'),
    path('admin-login/', views.admin_login, name='admin_login'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-logout/', views.admin_logout, name='admin_logout'),
    path('farmer-login/', views.farmer_login, name='farmer_login'),
    path('farmer-dashboard/', views.farmer_dashboard, name='farmer_dashboard'),
    path('farmer-logout/', views.farmer_logout, name='farmer_logout'),
    path('update-password/', update_password, name='update_password'),
    path('user-login/', views.user_login, name='user_login'),
    path('user-dashboard/', views.user_dashboard, name='user_dashboard'),
    path('farmer-logout/', views.user_logout, name='user_logout'),
    path('view-farmers/', views.view_farmers, name='view_farmers'),
    path('delete-farmer/<int:id>/', views.delete_farmer, name='delete_farmer'),
    path('add-soil-details/', views.add_soil_details, name='add_soil_details'),
    path('manage-soil-details/', views.manage_soil_details, name='manage_soil_details'),
    path('update-soil/<int:soil_id>/', views.update_soil, name='update_soil'),
    path('delete-soil/<int:soil_id>/', views.delete_soil, name='delete_soil'),
    path('add-fertilizer/',views.add_fertilizer, name='add_fertilizer'),
    path('manage-fertilizer/',views.manage_fertilizer, name='manage_fertilizer'),
    path('update-fertilizer/<int:id>/', views.update_fertilizer, name='update_fertilizer'),
    path('delete-fertilizer/<int:id>/', views.delete_fertilizer, name='delete_fertilizer'),
    path('view-soil-info/', views.view_soil_info, name='view_soil_info'),
    path('view-fertilizer-info/', views.view_fertilizer_info, name='view_fertilizer_info'),
    path('add-product/', views.add_product, name='add_product'),
    path('manage-product/', views.manage_product, name='manage_product'),
    path('product/delete/<int:product_id>/', views.delete_product, name='delete_product'),
    path('product/update/<int:product_id>/', views.update_product, name='update_product'),
    path('send-feedback/', views.send_feedback, name='send_feedback'),
    path('send-response/', views.send_response, name='send_response'),
    path('view-response/', views.view_response, name='view_response'),
    path('logout/', auth_views.LogoutView.as_view(next_page='index'), name='logout'),    
    path('buy/', views.buy_product_page, name='buy_product_page'),
    path('buy-product/<int:product_id>/', views.buy_product, name='buy_product'),
    path('order-status/', views.order_status, name='order_status'),
    path('orders/cancel/<int:order_id>/', views.cancel_order, name='cancel_order'),
    path('buy/<int:product_id>/', views.buy_product, name='buy_product'),
    path('orders/', views.order_status, name='order_status'),
    path('orders/cancel/<int:order_id>/', views.cancel_order, name='cancel_order'),
    path('view-order/', views.view_order, name='view_order'),
    path('respond-order/<int:order_id>/', views.respond_order, name='respond_order'),    
    path('make-payment/<int:order_id>/', views.make_payment, name='make_payment'),
    path('payment/', views.payment_page, name='payment'),
    path('payment/make/<int:order_id>/', views.make_payment, name='make_payment'),
    path('payment/<int:order_id>/', views.payment_single, name='payment_single'),
    path('payment/make/<int:order_id>/', views.make_payment, name='make_payment'),
    path('orders/history/', views.order_history, name='order_history'),
    path('payment/view/', views.view_payment_info, name='view_payment'),
    path('payment/update/<int:order_id>/', views.update_delivery_status, name='update_delivery_status'),
    path("recommend-fertilizer/", views.fertilizer_recommend_view, name="recommend_fertilizer"),


]
