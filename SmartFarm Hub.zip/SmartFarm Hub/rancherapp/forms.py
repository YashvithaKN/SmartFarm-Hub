from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Soil
from .models import Fertilizer 
from .models import Product
from .models import Feedback
from .models import Response


class FarmerRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class SoilForm(forms.ModelForm):
    class Meta:
        model = Soil
        fields = ['soil_type', 'region']
        

class FertilizerForm(forms.ModelForm):
    class Meta:
        model = Fertilizer
        fields = ['name', 'type', 'image', 'description']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Fertilizer Name'}),
            'type': forms.Select(attrs={'class': 'form-control'}),
            'image': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Enter details about the fertilizer'}),
        }

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'image', 'price', 'about']



class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['user_name', 'farmer_name', 'rating', 'message']
        widgets = {
            'rating': forms.NumberInput(attrs={'type': 'range', 'min': '0', 'max': '100'}),
        }

class ResponseForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['response']